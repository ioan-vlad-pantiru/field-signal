DEMO DATA - not a real farmer's export.

Ferma mare (demo): 155 parcels, 368.01 ha, Alba county.

Parcel outlines and areas are real public APIA parcels (2025 single-application declarations,
data.gov.ro, "Parcele agricole AGI Online APIA", CC BY 4.0). Which parcels form this farm, the
2025 crops (cultura) and the physical block ids (bloc_fizic) are made up. The crop code column
(cod_cult) is deliberately empty. The real AGI Online export format is not public; this file
only imitates its likely shape: an ESRI shapefile in Stereo 70 (EPSG:3844).

Made by data/scripts/make_mock_farm_export.py (Field Signal).
